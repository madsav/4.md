Probl�mas ar ko sask�ros:
Biju pl�nojusi, ka tikai br�d�, kad tiktu veikts drag and drop sf�ra s�ktu ri��ot ap modeli. M��in�ju to tais�t ar 'if' izmantojot EventListener, bet kaut kas t� ar� nesan�ca. da�a no t� ir palikusi nokoment�ta.


Izmantotie materi�li:
https://github.com/mrdoob
https://www.youtube.com/watch?v=mqjwgTAGQRY
https://github.com/learnthreejs/three-js-boilerplate/blob/example-dragcontrols-finish/public/examples/draggable-objects-dragcontrols/scripts.js
https://www.youtube.com/watch?v=gEZcJ3GufmE
https://github.com/mrdoob/three.js/blob/master/examples/webgl_mirror.html
https://discourse.threejs.org/t/solved-mesure-distance-between-two-points-on-a-object-by-clicking/6082/10


